/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/_app";
exports.ids = ["pages/_app"];
exports.modules = {

/***/ "./app/store.js":
/*!**********************!*\
  !*** ./app/store.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"store\": () => (/* binding */ store)\n/* harmony export */ });\n/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @reduxjs/toolkit */ \"@reduxjs/toolkit\");\n/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _slices_basketSlice__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../slices/basketSlice */ \"./slices/basketSlice.js\");\n\n\n//The global store setup\nconst store = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.configureStore)({\n    reducer: {\n        basket: _slices_basketSlice__WEBPACK_IMPORTED_MODULE_1__[\"default\"]\n    }\n});\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9hcHAvc3RvcmUuanMuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQUFpRDtBQUNBO0FBRWpELEVBQXdCO0FBQ2pCLEtBQUssQ0FBQ0UsS0FBSyxHQUFHRixnRUFBYyxDQUFDLENBQUM7SUFDakNHLE9BQU8sRUFBQyxDQUFDO1FBQ0xDLE1BQU0sRUFBRUgsMkRBQWE7SUFDekIsQ0FBQztBQUNMLENBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9uZXh0X2FtYXpvbmVfY2xvbmUvLi9hcHAvc3RvcmUuanM/Y2FlNiJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBjb25maWd1cmVTdG9yZSB9IGZyb20gJ0ByZWR1eGpzL3Rvb2xraXQnXG5pbXBvcnQgYmFza2V0UmVkdWNlciBmcm9tICcuLi9zbGljZXMvYmFza2V0U2xpY2UnXG5cbi8vVGhlIGdsb2JhbCBzdG9yZSBzZXR1cFxuZXhwb3J0IGNvbnN0IHN0b3JlID0gY29uZmlndXJlU3RvcmUoe1xuICAgIHJlZHVjZXI6e1xuICAgICAgICBiYXNrZXQ6IGJhc2tldFJlZHVjZXIsXG4gICAgfVxufSlcbiJdLCJuYW1lcyI6WyJjb25maWd1cmVTdG9yZSIsImJhc2tldFJlZHVjZXIiLCJzdG9yZSIsInJlZHVjZXIiLCJiYXNrZXQiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./app/store.js\n");

/***/ }),

/***/ "./pages/_app.js":
/*!***********************!*\
  !*** ./pages/_app.js ***!
  \***********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next-auth/react */ \"next-auth/react\");\n/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-redux */ \"react-redux\");\n/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _app_store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../app/store */ \"./app/store.js\");\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../styles/globals.css */ \"./styles/globals.css\");\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_css__WEBPACK_IMPORTED_MODULE_4__);\n\n\n\n\n\nfunction MyApp({ Component , pageProps: { session , ...pageProps }  }) {\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_auth_react__WEBPACK_IMPORTED_MODULE_1__.SessionProvider, {\n        session: session,\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_redux__WEBPACK_IMPORTED_MODULE_2__.Provider, {\n            store: _app_store__WEBPACK_IMPORTED_MODULE_3__.store,\n            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Component, {\n                ...pageProps\n            }, void 0, false, {\n                fileName: \"/Users/john_mighty_kelvin_david_walton/Desktop/Evaly/pages/_app.js\",\n                lineNumber: 10,\n                columnNumber: 9\n            }, this)\n        }, void 0, false, {\n            fileName: \"/Users/john_mighty_kelvin_david_walton/Desktop/Evaly/pages/_app.js\",\n            lineNumber: 9,\n            columnNumber: 7\n        }, this)\n    }, void 0, false, {\n        fileName: \"/Users/john_mighty_kelvin_david_walton/Desktop/Evaly/pages/_app.js\",\n        lineNumber: 8,\n        columnNumber: 5\n    }, this));\n}\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyApp);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9fYXBwLmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7O0FBQWlEO0FBQ1g7QUFDRjtBQUNOO1NBRXJCRyxLQUFLLENBQUMsQ0FBQyxDQUFDQyxTQUFTLEdBQUVDLFNBQVMsRUFBQyxDQUFDLENBQUNDLE9BQU8sTUFBS0QsU0FBUyxDQUFDLENBQUMsRUFBQyxDQUFDLEVBQUUsQ0FBQztJQUNsRSxNQUFNLDZFQUNITCw0REFBZTtRQUFDTSxPQUFPLEVBQUVBLE9BQU87OEZBQzlCTCxpREFBUTtZQUFDQyxLQUFLLEVBQUVBLDZDQUFLO2tHQUNuQkUsU0FBUzttQkFBS0MsU0FBUzs7Ozs7Ozs7Ozs7Ozs7OztBQUloQyxDQUFDO0FBRUQsaUVBQWVGLEtBQUsiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9uZXh0X2FtYXpvbmVfY2xvbmUvLi9wYWdlcy9fYXBwLmpzP2UwYWQiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgU2Vzc2lvblByb3ZpZGVyIH0gZnJvbSBcIm5leHQtYXV0aC9yZWFjdFwiXG5pbXBvcnQgeyBQcm92aWRlciB9IGZyb20gJ3JlYWN0LXJlZHV4J1xuaW1wb3J0IHsgc3RvcmUgfSBmcm9tICcuLi9hcHAvc3RvcmUnXG5pbXBvcnQgJy4uL3N0eWxlcy9nbG9iYWxzLmNzcydcblxuZnVuY3Rpb24gTXlBcHAoeyBDb21wb25lbnQsIHBhZ2VQcm9wczp7IHNlc3Npb24sIC4uLnBhZ2VQcm9wcyB9IH0pIHtcbiAgcmV0dXJuIChcbiAgICA8U2Vzc2lvblByb3ZpZGVyIHNlc3Npb249e3Nlc3Npb259PlxuICAgICAgPFByb3ZpZGVyIHN0b3JlPXtzdG9yZX0+XG4gICAgICAgIDxDb21wb25lbnQgey4uLnBhZ2VQcm9wc30gLz5cbiAgICAgIDwvUHJvdmlkZXI+XG4gICAgPC9TZXNzaW9uUHJvdmlkZXI+XG4gIClcbn1cblxuZXhwb3J0IGRlZmF1bHQgTXlBcHBcbiJdLCJuYW1lcyI6WyJTZXNzaW9uUHJvdmlkZXIiLCJQcm92aWRlciIsInN0b3JlIiwiTXlBcHAiLCJDb21wb25lbnQiLCJwYWdlUHJvcHMiLCJzZXNzaW9uIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/_app.js\n");

/***/ }),

/***/ "./slices/basketSlice.js":
/*!*******************************!*\
  !*** ./slices/basketSlice.js ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"addToBasket\": () => (/* binding */ addToBasket),\n/* harmony export */   \"removeFromBasket\": () => (/* binding */ removeFromBasket),\n/* harmony export */   \"incrementQuantity\": () => (/* binding */ incrementQuantity),\n/* harmony export */   \"decrementQuantity\": () => (/* binding */ decrementQuantity),\n/* harmony export */   \"selectItems\": () => (/* binding */ selectItems),\n/* harmony export */   \"selectTotal\": () => (/* binding */ selectTotal),\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @reduxjs/toolkit */ \"@reduxjs/toolkit\");\n/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);\n\nconst initialState = {\n    items: []\n};\nconst basketSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({\n    name: \"basket\",\n    initialState,\n    reducers: {\n        addToBasket: (state, action)=>{\n            const itemExists = state.items.find((item)=>item.id === action.payload.id\n            );\n            if (itemExists) {\n                itemExists.quantity++;\n            } else {\n                state.items = [\n                    ...state.items,\n                    {\n                        ...action.payload,\n                        quantity: 1\n                    }\n                ];\n            }\n        },\n        incrementQuantity: (state, action)=>{\n            const item1 = state.items.find((item)=>item.id === action.payload\n            );\n            item1.quantity++;\n        },\n        decrementQuantity: (state, action)=>{\n            const item2 = state.items.find((item)=>item.id === action.payload\n            );\n            if (item2.quantity === 1) {\n                const index = state.items.findIndex((item)=>item.id === action.payload\n                );\n                state.items.splice(index, 1);\n            } else {\n                item2.quantity--;\n            }\n        },\n        removeFromBasket: (state, action)=>{\n            const index = state.items.findIndex((basketItem)=>basketItem.id === action.payload.id\n            );\n            let newBasket = [\n                ...state.items\n            ];\n            if (index >= 0) {\n                newBasket.splice(index, 1);\n            } else {\n                console.warn(`can't remove product (id: ${action.payload.id}) as is not in the cart`);\n            }\n            state.items = newBasket;\n        }\n    }\n});\nconst { addToBasket , removeFromBasket , incrementQuantity , decrementQuantity  } = basketSlice.actions;\n//Selectors- this is how we pull information from the global store slice\nconst selectItems = (state)=>state.basket.items\n;\nconst selectTotal = (state)=>state.basket.items.reduce((total, item)=>total + item.price\n    , 0)\n;\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (basketSlice.reducer);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zbGljZXMvYmFza2V0U2xpY2UuanMuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7O0FBQThDO0FBRTlDLEtBQUssQ0FBQ0MsWUFBWSxHQUFHLENBQUM7SUFDbEJDLEtBQUssRUFBQyxDQUFDLENBQUM7QUFDWixDQUFDO0FBRUQsS0FBSyxDQUFDQyxXQUFXLEdBQUdILDZEQUFXLENBQUMsQ0FBQztJQUM3QkksSUFBSSxFQUFDLENBQVE7SUFDYkgsWUFBWTtJQUNaSSxRQUFRLEVBQUMsQ0FBQztRQUNOQyxXQUFXLEdBQUdDLEtBQUssRUFBRUMsTUFBTSxHQUFLLENBQUM7WUFDN0IsS0FBSyxDQUFDQyxVQUFVLEdBQUdGLEtBQUssQ0FBQ0wsS0FBSyxDQUFDUSxJQUFJLEVBQUVDLElBQUksR0FBS0EsSUFBSSxDQUFDQyxFQUFFLEtBQUtKLE1BQU0sQ0FBQ0ssT0FBTyxDQUFDRCxFQUFFOztZQUMzRSxFQUFFLEVBQUVILFVBQVUsRUFBRSxDQUFDO2dCQUNmQSxVQUFVLENBQUNLLFFBQVE7WUFDckIsQ0FBQyxNQUFNLENBQUM7Z0JBQ0pQLEtBQUssQ0FBQ0wsS0FBSyxHQUFHLENBQUM7dUJBQUdLLEtBQUssQ0FBQ0wsS0FBSztvQkFBRSxDQUFDOzJCQUFJTSxNQUFNLENBQUNLLE9BQU87d0JBQUVDLFFBQVEsRUFBRSxDQUFDO29CQUFDLENBQUM7Z0JBQUEsQ0FBQztZQUN0RSxDQUFDO1FBQ0gsQ0FBQztRQUVIQyxpQkFBaUIsR0FBR1IsS0FBSyxFQUFFQyxNQUFNLEdBQUssQ0FBQztZQUNuQyxLQUFLLENBQUNHLEtBQUksR0FBR0osS0FBSyxDQUFDTCxLQUFLLENBQUNRLElBQUksRUFBRUMsSUFBSSxHQUFLQSxJQUFJLENBQUNDLEVBQUUsS0FBS0osTUFBTSxDQUFDSyxPQUFPOztZQUNsRUYsS0FBSSxDQUFDRyxRQUFRO1FBQ2YsQ0FBQztRQUVIRSxpQkFBaUIsR0FBR1QsS0FBSyxFQUFFQyxNQUFNLEdBQUssQ0FBQztZQUNuQyxLQUFLLENBQUNHLEtBQUksR0FBR0osS0FBSyxDQUFDTCxLQUFLLENBQUNRLElBQUksRUFBRUMsSUFBSSxHQUFLQSxJQUFJLENBQUNDLEVBQUUsS0FBS0osTUFBTSxDQUFDSyxPQUFPOztZQUNsRSxFQUFFLEVBQUVGLEtBQUksQ0FBQ0csUUFBUSxLQUFLLENBQUMsRUFBRSxDQUFDO2dCQUN4QixLQUFLLENBQUNHLEtBQUssR0FBR1YsS0FBSyxDQUFDTCxLQUFLLENBQUNnQixTQUFTLEVBQUVQLElBQUksR0FBS0EsSUFBSSxDQUFDQyxFQUFFLEtBQUtKLE1BQU0sQ0FBQ0ssT0FBTzs7Z0JBQ3hFTixLQUFLLENBQUNMLEtBQUssQ0FBQ2lCLE1BQU0sQ0FBQ0YsS0FBSyxFQUFFLENBQUM7WUFDN0IsQ0FBQyxNQUFNLENBQUM7Z0JBQ05OLEtBQUksQ0FBQ0csUUFBUTtZQUNmLENBQUM7UUFDSCxDQUFDO1FBRUhNLGdCQUFnQixHQUFHYixLQUFLLEVBQUVDLE1BQU0sR0FBSyxDQUFDO1lBQ2xDLEtBQUssQ0FBQ1MsS0FBSyxHQUFHVixLQUFLLENBQUNMLEtBQUssQ0FBQ2dCLFNBQVMsRUFDOUJHLFVBQVUsR0FBSUEsVUFBVSxDQUFDVCxFQUFFLEtBQUtKLE1BQU0sQ0FBQ0ssT0FBTyxDQUFDRCxFQUFFOztZQUd0RCxHQUFHLENBQUNVLFNBQVMsR0FBRyxDQUFDO21CQUFHZixLQUFLLENBQUNMLEtBQUs7WUFBQSxDQUFDO1lBRWhDLEVBQUUsRUFBQ2UsS0FBSyxJQUFJLENBQUMsRUFBQyxDQUFDO2dCQUNYSyxTQUFTLENBQUNILE1BQU0sQ0FBQ0YsS0FBSyxFQUFFLENBQUM7WUFDN0IsQ0FBQyxNQUFJLENBQUM7Z0JBQ0ZNLE9BQU8sQ0FBQ0MsSUFBSSxFQUFFLDBCQUEwQixFQUFFaEIsTUFBTSxDQUFDSyxPQUFPLENBQUNELEVBQUUsQ0FBQyx1QkFBdUI7WUFDdkYsQ0FBQztZQUVETCxLQUFLLENBQUNMLEtBQUssR0FBR29CLFNBQVM7UUFDM0IsQ0FBQztJQUNMLENBQUM7QUFDTCxDQUFDO0FBRU0sS0FBSyxDQUFDLENBQUMsQ0FBQ2hCLFdBQVcsR0FBRWMsZ0JBQWdCLEdBQUVMLGlCQUFpQixHQUFFQyxpQkFBaUIsRUFBQyxDQUFDLEdBQUdiLFdBQVcsQ0FBQ3NCLE9BQU87QUFFMUcsRUFBd0U7QUFDakUsS0FBSyxDQUFDQyxXQUFXLElBQUluQixLQUFLLEdBQUtBLEtBQUssQ0FBQ29CLE1BQU0sQ0FBQ3pCLEtBQUs7O0FBQ2pELEtBQUssQ0FBQzBCLFdBQVcsSUFBSXJCLEtBQUssR0FBSUEsS0FBSyxDQUFDb0IsTUFBTSxDQUFDekIsS0FBSyxDQUFDMkIsTUFBTSxFQUFFQyxLQUFLLEVBQUNuQixJQUFJLEdBQUltQixLQUFLLEdBQUduQixJQUFJLENBQUNvQixLQUFLO01BQUUsQ0FBQzs7QUFFbkcsaUVBQWU1QixXQUFXLENBQUM2QixPQUFPLEVBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9uZXh0X2FtYXpvbmVfY2xvbmUvLi9zbGljZXMvYmFza2V0U2xpY2UuanM/MTI2YyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBjcmVhdGVTbGljZSB9IGZyb20gJ0ByZWR1eGpzL3Rvb2xraXQnO1xuXG5jb25zdCBpbml0aWFsU3RhdGUgPSB7XG4gICAgaXRlbXM6W11cbn1cblxuY29uc3QgYmFza2V0U2xpY2UgPSBjcmVhdGVTbGljZSh7XG4gICAgbmFtZTpcImJhc2tldFwiLFxuICAgIGluaXRpYWxTdGF0ZSxcbiAgICByZWR1Y2Vyczp7XG4gICAgICAgIGFkZFRvQmFza2V0OiAoc3RhdGUsIGFjdGlvbikgPT4ge1xuICAgICAgICAgICAgY29uc3QgaXRlbUV4aXN0cyA9IHN0YXRlLml0ZW1zLmZpbmQoKGl0ZW0pID0+IGl0ZW0uaWQgPT09IGFjdGlvbi5wYXlsb2FkLmlkKTtcbiAgICAgICAgICAgIGlmIChpdGVtRXhpc3RzKSB7XG4gICAgICAgICAgICAgIGl0ZW1FeGlzdHMucXVhbnRpdHkrKztcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgc3RhdGUuaXRlbXMgPSBbLi4uc3RhdGUuaXRlbXMsIHsgLi4uYWN0aW9uLnBheWxvYWQsIHF1YW50aXR5OiAxIH1dXG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSxcblxuICAgICAgICBpbmNyZW1lbnRRdWFudGl0eTogKHN0YXRlLCBhY3Rpb24pID0+IHtcbiAgICAgICAgICAgIGNvbnN0IGl0ZW0gPSBzdGF0ZS5pdGVtcy5maW5kKChpdGVtKSA9PiBpdGVtLmlkID09PSBhY3Rpb24ucGF5bG9hZCk7XG4gICAgICAgICAgICBpdGVtLnF1YW50aXR5Kys7XG4gICAgICAgICAgfSwgXG4gICAgICAgICAgXG4gICAgICAgIGRlY3JlbWVudFF1YW50aXR5OiAoc3RhdGUsIGFjdGlvbikgPT4ge1xuICAgICAgICAgICAgY29uc3QgaXRlbSA9IHN0YXRlLml0ZW1zLmZpbmQoKGl0ZW0pID0+IGl0ZW0uaWQgPT09IGFjdGlvbi5wYXlsb2FkKTtcbiAgICAgICAgICAgIGlmIChpdGVtLnF1YW50aXR5ID09PSAxKSB7XG4gICAgICAgICAgICAgIGNvbnN0IGluZGV4ID0gc3RhdGUuaXRlbXMuZmluZEluZGV4KChpdGVtKSA9PiBpdGVtLmlkID09PSBhY3Rpb24ucGF5bG9hZCk7XG4gICAgICAgICAgICAgIHN0YXRlLml0ZW1zLnNwbGljZShpbmRleCwgMSk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICBpdGVtLnF1YW50aXR5LS07XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSxcblxuICAgICAgICByZW1vdmVGcm9tQmFza2V0OiAoc3RhdGUsIGFjdGlvbikgPT4ge1xuICAgICAgICAgICAgY29uc3QgaW5kZXggPSBzdGF0ZS5pdGVtcy5maW5kSW5kZXgoXG4gICAgICAgICAgICAgICAgKGJhc2tldEl0ZW0pPT4gYmFza2V0SXRlbS5pZCA9PT0gYWN0aW9uLnBheWxvYWQuaWRcbiAgICAgICAgICAgICk7XG5cbiAgICAgICAgICAgIGxldCBuZXdCYXNrZXQgPSBbLi4uc3RhdGUuaXRlbXNdXG5cbiAgICAgICAgICAgIGlmKGluZGV4ID49IDApe1xuICAgICAgICAgICAgICAgIG5ld0Jhc2tldC5zcGxpY2UoaW5kZXgsIDEpO1xuICAgICAgICAgICAgfWVsc2V7XG4gICAgICAgICAgICAgICAgY29uc29sZS53YXJuKGBjYW4ndCByZW1vdmUgcHJvZHVjdCAoaWQ6ICR7YWN0aW9uLnBheWxvYWQuaWR9KSBhcyBpcyBub3QgaW4gdGhlIGNhcnRgKVxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBzdGF0ZS5pdGVtcyA9IG5ld0Jhc2tldDtcbiAgICAgICAgfVxuICAgIH1cbn0pXG5cbmV4cG9ydCBjb25zdCB7IGFkZFRvQmFza2V0LCByZW1vdmVGcm9tQmFza2V0LCBpbmNyZW1lbnRRdWFudGl0eSwgZGVjcmVtZW50UXVhbnRpdHkgfSA9IGJhc2tldFNsaWNlLmFjdGlvbnM7XG5cbi8vU2VsZWN0b3JzLSB0aGlzIGlzIGhvdyB3ZSBwdWxsIGluZm9ybWF0aW9uIGZyb20gdGhlIGdsb2JhbCBzdG9yZSBzbGljZVxuZXhwb3J0IGNvbnN0IHNlbGVjdEl0ZW1zID0gKHN0YXRlKSA9PiBzdGF0ZS5iYXNrZXQuaXRlbXM7XG5leHBvcnQgY29uc3Qgc2VsZWN0VG90YWwgPSAoc3RhdGUpPT4gc3RhdGUuYmFza2V0Lml0ZW1zLnJlZHVjZSgodG90YWwsaXRlbSk9PiB0b3RhbCArIGl0ZW0ucHJpY2UsIDApXG5cbmV4cG9ydCBkZWZhdWx0IGJhc2tldFNsaWNlLnJlZHVjZXI7Il0sIm5hbWVzIjpbImNyZWF0ZVNsaWNlIiwiaW5pdGlhbFN0YXRlIiwiaXRlbXMiLCJiYXNrZXRTbGljZSIsIm5hbWUiLCJyZWR1Y2VycyIsImFkZFRvQmFza2V0Iiwic3RhdGUiLCJhY3Rpb24iLCJpdGVtRXhpc3RzIiwiZmluZCIsIml0ZW0iLCJpZCIsInBheWxvYWQiLCJxdWFudGl0eSIsImluY3JlbWVudFF1YW50aXR5IiwiZGVjcmVtZW50UXVhbnRpdHkiLCJpbmRleCIsImZpbmRJbmRleCIsInNwbGljZSIsInJlbW92ZUZyb21CYXNrZXQiLCJiYXNrZXRJdGVtIiwibmV3QmFza2V0IiwiY29uc29sZSIsIndhcm4iLCJhY3Rpb25zIiwic2VsZWN0SXRlbXMiLCJiYXNrZXQiLCJzZWxlY3RUb3RhbCIsInJlZHVjZSIsInRvdGFsIiwicHJpY2UiLCJyZWR1Y2VyIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./slices/basketSlice.js\n");

/***/ }),

/***/ "./styles/globals.css":
/*!****************************!*\
  !*** ./styles/globals.css ***!
  \****************************/
/***/ (() => {



/***/ }),

/***/ "@reduxjs/toolkit":
/*!***********************************!*\
  !*** external "@reduxjs/toolkit" ***!
  \***********************************/
/***/ ((module) => {

"use strict";
module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ "next-auth/react":
/*!**********************************!*\
  !*** external "next-auth/react" ***!
  \**********************************/
/***/ ((module) => {

"use strict";
module.exports = require("next-auth/react");

/***/ }),

/***/ "react-redux":
/*!******************************!*\
  !*** external "react-redux" ***!
  \******************************/
/***/ ((module) => {

"use strict";
module.exports = require("react-redux");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/_app.js"));
module.exports = __webpack_exports__;

})();