import React from 'react';
import { Carousel } from 'react-responsive-carousel';
import "react-responsive-carousel/lib/styles/carousel.min.css"; // requires a loader
import Categories from './categories';
import Image from 'next/image';

import toy1 from '../public/toy1.png'
import toy2 from '../public/toy2.png'
import toy3 from '../public/toy3.png'





const Banner = () => {
    return (
        <div className='bottom-0 mb-0 pb-0'>
        <div className='relative carousel-slider'>
            <div className='  absolute w-full bg-gradient-to-t from-gray-100 to-transparent bottom-0 z-20'></div>
            <Carousel
                autoPlay
                infiniteLoop
                showStatus={false}
                showIndicators={false}
                showThumbs={false}
                interval={5000}
                animationHandler
            >
                <div>
                    <img src='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSTO60byFZGMO1ZWDJ7nBMoci2tT2evd0ZRQA&usqp=CAU' alt=""  className='h-[500px]  rounded-[2rem] pl-5 pr-5  mt-3  ' style={{objectFit: 'cover'}} />
                </div>
                <div>
                    <img src='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSDaPRTeX3kMpFk2dtbYYpcbWcmPc_7f4bu_DV6EEhUaUXJTnIl2bgvBu1_HUea2jbtQsM&usqp=CAU' alt="" className='h-[500px] w-full rounded-[2rem] pl-5 pr-5  mt-3' style={{objectFit: 'contain'}}/>
                </div>
                <div>
                    <img  src='https://target.scene7.com/is/image/Target/GUEST_81633444-21ee-43c9-a1c2-7031862ab07c' className='h-[500px] w-full rounded-[2rem] pl-5 pr-5 mt-3 '  alt=""style={{objectFit: 'cover'}} />
                </div>

            </Carousel>
        </div>
        </div>
    );
};

export default Banner;