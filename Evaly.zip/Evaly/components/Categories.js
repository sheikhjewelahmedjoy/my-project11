import React from 'react'
import Image from 'next/image'
import Faqs from '../public/Faqs.png'
import love from '../public/love.png'
import cat from '../public/cat.png'
 import order from '../public/order.png'
import Banner from './Banner'



const Categories = () => {
  return (

    <div className=' flex w-full flex justify-between align-center flex-wrap' >
      

       
<div className='flex  w-[100px] h-[100px] flex-col m-5 bg-white  rounded-full'>
{/* <p className='absolute  right-2 text-xs italic text-gray-400'></p> */}

{/* <Image src={Faqs} alt="faq" width={40} height={40} className=''/> */}
<h4 className='text-center pt-10'>FAQ</h4>

</div>
<div className=' w-[100px] h-[100px]  flex  flex-col m-5 bg-white  rounded-full'>
{/* <p className='absolute  right-2 text-xs italic text-gray-400'></p> */}

{/* <Image src={Faqs} alt="faq" width={40} height={40} className='flex justify-center align-center pt-2'/> */}
<h4 className='text-center pt-10'>wishlist</h4>

</div><div className='  w-[100px] h-[100px]  flex  flex-col m-5 bg-white  rounded-full'>
{/* <p className='absolute  right-2 text-xs italic text-gray-400'></p> */}

{/* <Image src={Faqs} alt="faq" width={40} height={40} className='pt-2'/> */}
<h4 className='text-center pt-10'>Express</h4>

</div>
<div className=' w-[100px] h-[100px]  flex  flex-col m-5 bg-white  rounded-full'>
{/* <p className='absolute  right-2 text-xs italic text-gray-400'></p> */}

{/* <Image src={Faqs} alt="faq" width={40} height={40} className='flex justify-center align-center'/> */}
<h4 className='text-center pt-10'>Categories</h4>

</div><div className=' w-[100px] h-[100px]  flex  flex-col m-5 bg-white  rounded-full'>
{/* <p className='absolute  right-2 text-xs italic text-gray-400'></p> */}

{/* <Image src={Faqs} alt="faq" width={20} height={20} className='pt-6' style={{objectFit: 'fit'}}/> */}
<h4 className='text-center pt-10'>Order</h4>

</div>
</div>



    
  )
}

export default Categories

