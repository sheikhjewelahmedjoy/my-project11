# NextJs Amazone Clone Template

## API Fetch From -

fakestoreapi.com which link is-
[Link](https://fakestoreapi.com/)

## Google Authentication setup

rename .env.example file like as .env and put your GOOGLE_ID and GOOGLE_SECRET.

## Stripe Setup

rename .env.example file like as .env and put your STRIPE_PUBLIC_KEY and STRIPE_SECRET_KEY.

---

## Site Home Screen Shot

![This is a alt text.](/public/picture-1.jpg)

---

## Site Cart Screen Shot

![This is a alt text.](/public/picture-2.jpg)

## Install and Run

1. npm install
2. npm run dev
# evaly
